<div id="footer">
Авторские права &copy; <?php echo date('Y'); ?> <a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a> Все права защищены | &nbsp; <a class="rsslink" href="<?php bloginfo('rss2_url') ?>" title="RSS Feed">RSS</a><br>Локализовано: русскоязычные <a href="http://freewordpressthemes.ru/" title="Темы WordPress на русском!">ВордПресс</a> шаблоны
</div>

<?php wp_footer() ?>

</body>
</html>
